import { Component } from "react";
import "./index.css";
class SearchBar extends Component {
  render() {
    return (
      <div className="searchbar">
        <div className="select-container">
          <p>what are you looking for?</p>
          <input
            type="search"
            placeholder="Search for category, name, company, etc"
            className="select-item"
          />
        </div>
        <div className="select-container">
          <p>Category</p>
          <select className="select-item">
            <option value="all" selected>
              All
            </option>
          </select>
        </div>
        <div className="select-container">
          <p>status</p>
          <select className="select-item">
            <option value="all" selected className="select-item">
              All
            </option>
          </select>
        </div>
        <button></button>
        <button className="search-button select-container">Search</button>
      </div>
    );
  }
}
export default SearchBar;
