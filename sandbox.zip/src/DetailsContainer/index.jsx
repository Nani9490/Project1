import { Component } from "react";
import "./index.css";
import TableContainer from "./TableContainer/index";
import Page from "./Page/index";

class DetailsContainer extends Component {
  render() {
    return (
      <div className="details-container">
        <div className="container">
          <h3>Product Summary</h3>
          <div className="filter-container">
            <label className="element">Column</label>
            <select className="element">
              <option value="all" selected>
                All COLUMN
              </option>
            </select>
            <button className="button-element element">
              DISPATCH SELECTED
            </button>
            <Page />
          </div>
        </div>
        <TableContainer />
      </div>
    );
  }
}
export default DetailsContainer;
