import { Component } from "react";
import "./styles.css";
import SearchBar from "./SearchBar/index";
import DetailsContainer from "./DetailsContainer/index";

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="heading-element">
          <h1> Orders </h1>
          <button className="create-button"> CREATE NEW </button>
        </div>
        <div>
          <SearchBar />
        </div>
        <div>
          <DetailsContainer />
        </div>
      </div>
    );
  }
}
export default App;
