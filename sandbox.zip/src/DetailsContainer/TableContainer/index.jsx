import { Component } from "react";
import "./index.css";

const data = [
  {
    id: 1077620,
    testId: 1,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077622,
    testId: 2,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077623,
    testId: 3,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077620,
    testId: 4,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077620,
    testId: 5,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077620,
    testId: 6,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077620,
    testId: 7,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077620,
    testId: 8,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
  {
    id: 1077620,
    testId: 9,
    shpify: 17713,
    date: "22 Jan 2020",
    status: "pending",
    customer: "Ahmed",
    email: "ahmed.123@mail.com",
    country: "Australia",
    shipping: "Austrelian Post Api",
    sourse: "ShopifyAU",
    ordertype: "Customer",
  },
];

class TableContainer extends Component {
  render() {
    return (
      <div>
        <table className="table-container">
          <thead>
            <input type="checkbox" id="checkElement" />
            <label htmlFor="checkElement">ID</label>
            <th>SHIPIFY#</th>
            <th>DATE</th>
            <th>STATUS</th>
            <th>CUSTOMER</th>
            <th>EMAIL</th>
            <th>COUNTRY</th>
            <th>SHIPPING</th>
            <th>SOURSE</th>
            <th>ORDER TYPE</th>
          </thead>
          {data.map((each) => (
            <tbody>
              <input type="checkbox" id={each.testId} />
              <label htmlFor={each.testId}>{each.id}</label>
              <td>{each.shpify}</td>
              <td>{each.date}</td>
              <td>{each.status}</td>
              <td>{each.customer}</td>
              <td>{each.email}</td>
              <td>{each.country}</td>
              <td>{each.shipping}</td>
              <td>{each.sourse}</td>
              <td>
                {each.ordertype}
                <span> 📝</span>
              </td>
            </tbody>
          ))}
        </table>
      </div>
    );
  }
}
export default TableContainer;
