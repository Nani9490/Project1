import { Component } from "react";
import "./index.css";

const Array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
class Page extends Component {
  state = {
    currentPage: 3,
  };

  render() {
    const { currentPage } = this.state;
    return (
      <div className="page-numbers">
        <button>{"<"}</button>
        <div className="page-numbers">
          {Array.map((item) => (
            <p
              className={currentPage === item ? "active-block" : "normal-block"}
            >
              {item}
            </p>
          ))}
        </div>
        <button>{">"}</button>
      </div>
    );
  }
}
export default Page;
